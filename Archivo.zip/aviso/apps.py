from django.apps import AppConfig


class AvisoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aviso'
